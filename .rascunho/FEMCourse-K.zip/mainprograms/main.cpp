

#include <iostream>
#include <math.h>
#include <TMatrix.h>

using std::cout;
using std::endl;
using std::cin;

int main ()
{
    TVec<double> vec1;
  
    return 0;
}