//
//  DataTypes.h
//  FemSC
//
//  Created by Philippe Devloo on 03/04/18.
//

#ifndef DataTypes_h
#define DataTypes_h

#include "TVecNum.h"

typedef TVecNum<double> VecDouble2;


#endif /* DataTypes_h */
